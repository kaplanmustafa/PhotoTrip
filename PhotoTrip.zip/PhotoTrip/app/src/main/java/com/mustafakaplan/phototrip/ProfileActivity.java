package com.mustafakaplan.phototrip;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import com.squareup.picasso.Picasso;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.PicassoProvider;

import java.util.ArrayList;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    static boolean photoDelete = true;
    static String currentEmail="";
    static boolean updatePhoto=false;
    String showUser;
    String ppUrl;

    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firebaseFirestore;

    ProfileRecycleAdapter profileRecycleAdapter;

    ArrayList<String> userCommentFromFB;
    ArrayList<String> userImageFromFB;
    static ArrayList<String> userAddressFromFB;
    static ArrayList<String> userLatitudeFromFB;
    static ArrayList<String> userLongitudeFromFB;

    TextView nameText;
    TextView aboutText;
    ImageView profilePhoto;
    Button editButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        Intent intent = getIntent();
        showUser = intent.getStringExtra("showUser");

        nameText = findViewById(R.id.nameText);
        aboutText = findViewById(R.id.aboutText);
        profilePhoto = findViewById(R.id.profilePhoto);
        profilePhoto.setImageResource(R.drawable.user);
        editButton = findViewById(R.id.editButton);

        userCommentFromFB = new ArrayList<>();
        userImageFromFB = new ArrayList<>();
        userAddressFromFB = new ArrayList<>();
        userLatitudeFromFB = new ArrayList<>();
        userLongitudeFromFB = new ArrayList<>();

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

        getDataFromFirestore();
        getDataFromFirestore2();

        RecyclerView recyclerView = findViewById(R.id.recyclerProfileView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        profileRecycleAdapter = new ProfileRecycleAdapter(userCommentFromFB,userImageFromFB,userAddressFromFB);

        recyclerView.setAdapter(profileRecycleAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(updatePhoto == true)
        {
            getDataFromFirestore2();
            updatePhoto = false;
        }
    }

    public void editProfile(View view)
    {
        EditProfileActivity.oldName = nameText.getText().toString();
        EditProfileActivity.oldAbout = aboutText.getText().toString();
        EditProfileActivity.oldImage = ppUrl;
        System.out.println("Üst : " + ppUrl);

        Intent intentToEditProfile = new Intent(ProfileActivity.this,EditProfileActivity.class);
        startActivity(intentToEditProfile);
    }

    public void getDataFromFirestore()
    {
        CollectionReference collectionReference = firebaseFirestore.collection("Posts");

        collectionReference.orderBy("date", Query.Direction.DESCENDING).addSnapshotListener(new EventListener<QuerySnapshot>()
        {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e)
            {
                if(e != null)
                {
                    Toast.makeText(ProfileActivity.this,e.getLocalizedMessage().toString(),Toast.LENGTH_LONG).show();
                }
                else
                {
                    if(queryDocumentSnapshots != null)
                    {
                        for(DocumentSnapshot snapshot : queryDocumentSnapshots.getDocuments())
                        {
                            Map<String,Object> data = snapshot.getData();

                            String userEmail = (String) data.get("useremail");

                            if(showUser == null)
                            {
                                if(userEmail.matches(currentEmail)) // Profilde sadece kendi fotoğraflarını göster
                                {
                                    String comment = (String) data.get("comment");
                                    String downloadUrl = (String) data.get("downloadurl");
                                    String address = (String) data.get("address");
                                    String latitude = (String) data.get("latitude");
                                    String longitude = (String) data.get("longitude");

                                    userCommentFromFB.add(comment);
                                    userImageFromFB.add(downloadUrl);
                                    userAddressFromFB.add(address);
                                    userLatitudeFromFB.add(latitude);
                                    userLongitudeFromFB.add(longitude);

                                    profileRecycleAdapter.notifyDataSetChanged();
                                }
                            }

                            else
                            {
                                if(!showUser.matches(currentEmail)) // Başka Profile Bakılınca Düzenleyi Kaldır
                                {
                                    editButton.setVisibility(View.INVISIBLE);
                                    photoDelete = false;
                                }

                                if(userEmail.matches(showUser)) // Başka Kişinin Profili
                                {
                                    String comment = (String) data.get("comment");
                                    String downloadUrl = (String) data.get("downloadurl");
                                    String address = (String) data.get("address");
                                    String latitude = (String) data.get("latitude");
                                    String longitude = (String) data.get("longitude");

                                    userCommentFromFB.add(comment);
                                    userImageFromFB.add(downloadUrl);
                                    userAddressFromFB.add(address);
                                    userLatitudeFromFB.add(latitude);
                                    userLongitudeFromFB.add(longitude);

                                    profileRecycleAdapter.notifyDataSetChanged();
                                }
                            }
                        }
                    }
                }
            }
        });

    }

    public void getDataFromFirestore2()
    {
        CollectionReference collectionReference2 = firebaseFirestore.collection("Users");

        collectionReference2.addSnapshotListener(new EventListener<QuerySnapshot>()
        {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e)
            {
                if(e != null)
                {
                    Toast.makeText(ProfileActivity.this,e.getLocalizedMessage().toString(),Toast.LENGTH_LONG).show();
                }
                else
                {
                    if(queryDocumentSnapshots != null)
                    {
                        for(DocumentSnapshot snapshot : queryDocumentSnapshots.getDocuments())
                        {
                            Map<String,Object> data = snapshot.getData();

                            String userEmail = (String) data.get("useremail");

                            if(showUser == null)
                            {
                                if(userEmail.matches(currentEmail)) // Profil fotoğrafını göster
                                {
                                    String fullName = (String) data.get("fullname");
                                    String aboutMe = (String) data.get("aboutme");
                                    ppUrl = (String) data.get("downloadurl");

                                    nameText.setText(fullName);
                                    aboutText.setText(aboutMe);
                                    Picasso.get().load(ppUrl).into(profilePhoto);

                                    break;
                                }
                            }
                            else
                            {
                                if(!showUser.matches(currentEmail)) // Başka Profile Bakılınca Düzenleyi Kaldır
                                {
                                    editButton.setVisibility(View.INVISIBLE);
                                }

                                if(userEmail.matches(showUser))                                 {
                                    String fullName = (String) data.get("fullname");
                                    String aboutMe = (String) data.get("aboutme");
                                    ppUrl = (String) data.get("downloadurl");

                                    nameText.setText(fullName);
                                    aboutText.setText(aboutMe);
                                    Picasso.get().load(ppUrl).into(profilePhoto);

                                    break;
                                }
                            }

                        }
                    }
                }
            }
        });
    }
}
